package com.bbm.gallery.app;

import android.content.Context; 
import android.view.LayoutInflater; 
import android.view.View; 
import android.view.ViewGroup; 
import android.widget.ImageView; 
import android.widget.Toast; 

import androidx.annotation.NonNull; 
import androidx.recyclerview.widget.RecyclerView; 

import java.util.List;
import java.util.HashMap;
import java.util.ArrayList;
import android.os.Build;
import android.app.Activity;
import android.transition.Explode;
import android.content.Intent;
import android.app.ActivityOptions;
import androidx.core.app.ActivityOptionsCompat;
import androidx.core.util.Pair;
import androidx.core.app.ActivityCompat;
import android.net.Uri;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import java.net.URL;
import android.graphics.BitmapFactory;
import android.graphics.Bitmap;
import java.net.MalformedURLException; 

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.MyHolder> { 

    Activity act;
    ArrayList<HashMap<String,Object>> list; 

    public MyAdapter(Activity act, ArrayList<HashMap<String,Object>> list) { 
        this.act = act; 
        this.list = list; 
    } 

    @NonNull 
    @Override 
    public MyHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) { 

        View view = LayoutInflater.from(act.getApplicationContext()).inflate(R.layout.listitem,viewGroup,false); 
        return new MyHolder(view); 
    } 

    @Override 
    public void onBindViewHolder(@NonNull MyHolder myHolder, final int i) { 

        //myHolder.image.setImageBitmap(FileUtil.decodeSampleBitmapFromPath(String.valueOf(list.get(i).get("i")), 1024, 1024));
        new Thread(
        new Runnable(){

            @Override
            public void run() {
                try {
                    final URL newurl = new URL(String.valueOf(list.get(i).get("i")));
                    final Bitmap mIcon_val = BitmapFactory.decodeStream(newurl.openConnection() .getInputStream()); 
                    act.runOnUiThread(new Runnable(){

                            @Override
                            public void run() {
                                myHolder.image.setImageBitmap(mIcon_val);
                                
                            }
                            
                    
                });
            } catch (final Exception e) {
                e.printStackTrace();
                act.runOnUiThread(new Runnable(){

                        @Override
                        public void run() {
                            myHolder.image.setImageResource(R.drawable.ic_retry);
                        }


                    });
            } 
                
         }
            
            
        }).start();
        myHolder.itemView.setOnClickListener(new View.OnClickListener() { 
                @Override 
                public void onClick(View view) { 
                    
                       Intent intent = new Intent(act, PictureActivity.class);
                            intent.putExtra("p",String.valueOf(list.get(i).get("i")));
                            ActivityOptionsCompat activityOptions = ActivityOptionsCompat.makeSceneTransitionAnimation(
                            act,

                            // Now we provide a list of Pair items which contain the view we can transitioning
                            // from, and the name of the view it is transitioning to, in the launched activity
                             new Pair<>(view.findViewById(R.id.image),
                             PictureActivity.VIEW_NAME_HEADER_IMAGE));

                    // Now we can start the Activity, providing the activity options as a bundle
                            ActivityCompat.startActivity(act, intent, activityOptions.toBundle());
                      
                        
                    }
                
         }); 
    } 

    @Override 
    public int getItemCount() { 
        return list.size(); 
    } 

    public static class MyHolder extends RecyclerView.ViewHolder { 

        ImageView image; 

        public MyHolder(@NonNull View itemView) { 
            super(itemView); 
            image = itemView.findViewById(R.id.image); 
        } 
    } 
} 
     

