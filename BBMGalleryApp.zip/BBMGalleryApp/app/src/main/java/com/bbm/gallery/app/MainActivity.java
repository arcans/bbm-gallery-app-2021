package com.bbm.gallery.app;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import android.os.Build;
import android.Manifest;
import android.content.pm.PackageManager;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;
import androidx.recyclerview.widget.GridLayoutManager;
import java.util.ArrayList;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import java.util.HashMap;
import android.app.ActivityOptions;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.Request;
import android.widget.Toast;
import android.content.ClipboardManager;
import android.content.ClipData;
import java.nio.file.Path;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.io.IOException;

public class MainActivity extends AppCompatActivity { 

    Toolbar tb;
    public static RecyclerView recyclerView; 
    public static MyAdapter myAdapter; 
    SwipeRefreshLayout refresher;
    ArrayList<HashMap<String,Object>>  list; 

    HashMap<String,Object> adder;
    GridLayoutManager layoutManager;
     
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initialize(savedInstanceState);
        if (Build.VERSION.SDK_INT >= 23) {
            if (ActivityCompat.checkSelfPermission(this,Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
                || checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
                requestPermissions(new String[] {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
            }
            else {
                initializeLogic();
            }
        }
        else {
            initializeLogic();
        }
   
    
    }

    private void initialize(Bundle sab) {
        tb = findViewById(R.id.toolbar_main);
        tb.setTitle("BBM Gallery App 2021");
        refresher= findViewById(R.id.pullToRefresh);
        recyclerView = findViewById(R.id.recycler_view); 
        
        refresher.setOnRefreshListener( new SwipeRefreshLayout.OnRefreshListener(){

                @Override
                public void onRefresh() {
                    refresher.setRefreshing(false);
                    getList();
                }
                
            
        });
        
        layoutManager = new GridLayoutManager(this,2); 
        recyclerView.setHasFixedSize(true); 

        layoutManager.setOrientation(RecyclerView.VERTICAL); 
        recyclerView.setLayoutManager(layoutManager);
  
    }

    private void initializeLogic() {
        getList();
        
       
        
    }
    
    private void getList() { 
        list = new ArrayList<>(); 
        adder = new HashMap<>();
        adder.put("i","https://assets2.rappler.com/2021/10/bongbong-marcos-bbm-cebu-october-22-2021-003-1634899201286-546.jpg");     
        list.add(adder);
        adder = new HashMap<>();
        adder.put("i","https://newsinfo.inquirer.net/files/2021/10/Ferdinand-Marcos-Jr.-101621.jpg?_gl=1*1v78iwd*_ga*c2RNZzdSN0tRSTN3V2sxUFN6U2tCc1dOLWNUOGVYbzQzNmVKd2tPSzZJbURQWjNlMEZhaE9QMjRGMnNFb1dMQQ..");
        list.add(adder);
        adder = new HashMap<>();
        adder.put("i","https://www.manilatimes.net/manilatimes/uploads/images/2021/08/22/13077.jpg");
        list.add(adder);
        adder = new HashMap<>();
        adder.put("i","https://assets2.rappler.com/2021/09/210915-Bongbong-Marcos-Toni-Gonzaga-interview-1631704550193-546.png");
        list.add(adder);
        adder = new HashMap<>();
        adder.put("i","https://storage.googleapis.com/afs-prod/media/a7d05c9fde594f289b033c8c2566d925/1000.jpeg");
        list.add(adder);
        adder = new HashMap<>();
        adder.put("i","https://img.monocle.com/gallery/1-51499474525ca.jpg");
        list.add(adder);
        adder = new HashMap<>();
        adder.put("i","https://www.manilatimes.net/manilatimes/uploads/images/2021/09/14/15837.jpg");
        list.add(adder);
        adder = new HashMap<>();
        adder.put("i","https://mb.com.ph/wp-content/uploads/2021/10/37660.jpeg");
        list.add(adder);
        adder = new HashMap<>();
        adder.put("i","https://www.y101fm.com/images/political-candidates/candidates-for-vice-president/bongbong-marcos.jpg");
        list.add(adder);
        adder = new HashMap<>();
        adder.put("i","https://www.bongbongmarcos.com/wp-content/uploads/2021/05/JPEGBBM-About.jpg");
        list.add(adder);
        
        recyclerView.setHasFixedSize(true); 
        
        myAdapter = new MyAdapter(MainActivity.this,list); 
        recyclerView.setAdapter(myAdapter); 
        
    } 
    
    
    
	
} 
