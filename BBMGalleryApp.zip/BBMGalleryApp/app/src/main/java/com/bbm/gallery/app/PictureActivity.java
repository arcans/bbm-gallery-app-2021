package com.bbm.gallery.app;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import android.os.Build;
import android.Manifest;
import android.content.pm.PackageManager;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;
import androidx.recyclerview.widget.GridLayoutManager;
import java.util.ArrayList;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import java.util.HashMap;
import android.app.ActivityOptions;
import android.view.Window;
import android.transition.Explode;
import android.widget.ImageView;
import androidx.core.view.ViewCompat;
import java.net.URL;
import android.graphics.BitmapFactory;
import android.graphics.Bitmap;
import android.widget.TextView;
import android.view.View.OnClickListener;
import android.view.View;

public class PictureActivity extends AppCompatActivity { 


    public static ImageView img;
    public static TextView tv;
    // Extra name for the ID parameter
    public static final String EXTRA_PARAM_ID = "detail:_id";

    // View name of the header image. Used for activity scene transitions
    public static final String VIEW_NAME_HEADER_IMAGE = "detail:header:image";    
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().requestFeature(Window.FEATURE_ACTIVITY_TRANSITIONS);

        // set an exit transition
        getWindow().setExitTransition(new Explode());

        setContentView(R.layout.activity_picture);
        initialize(savedInstanceState);
        initializeLogic();
        /*
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            // Apply activity transition
            getWindow().requestFeature(Window.FEATURE_ACTIVITY_TRANSITIONS);

            // set an exit transition
            getWindow().setExitTransition(new Explode());
        }
        */

    }

    private void initialize(Bundle sab) {
        img = findViewById(R.id.imagepic);
        tv = findViewById(R.id.textview1);
         ViewCompat.setTransitionName(img, VIEW_NAME_HEADER_IMAGE);

        img.setOnClickListener(new View.OnClickListener(){

                @Override
                public void onClick(View p1) {
                    loadImage();
                }
                
            
        });

    }

    private void initializeLogic() { 
        tv.setText(getIntent().getStringExtra("p"));
        
        loadImage();
        //img.setImageBitmap(FileUtil.decodeSampleBitmapFromPath(getIntent().getStringExtra("p"), 1024, 1024));
    }

    @Override
    public void onBackPressed() {  
        finishAfterTransition();
        super.onBackPressed();
    }
    
    
    public void loadImage(){
        new Thread(new Runnable(){

                @Override
                public void run() {
                    try {
                        final URL newurl = new URL(String.valueOf(getIntent().getStringExtra("p")));          
                        final Bitmap mIcon_val = BitmapFactory.decodeStream(newurl.openConnection() .getInputStream()); 
                        runOnUiThread(new Runnable(){

                                @Override
                                public void run() {
                                    img.setImageBitmap(mIcon_val);

                                }


                            });
                    } catch (final Exception e) {
                        e.printStackTrace();
                        runOnUiThread(new Runnable(){

                                @Override
                                public void run() {
                                    img.setImageResource(R.drawable.ic_retry);
                                }


                            });
                    } 
                }
            }).start();
    }
    

    



} 
